package com.h2a.builder

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputFilter
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val teal = Color.parseColor("#0F9688")
    private val dark = Color.parseColor("#1A1C2E")
    private val grey = Color.parseColor("#5B6172")
    private val colors = listOf("#0F9688", "#2196F3", "#E91E63", "#FF9800", "#9C27B0", "#F44336", "#4CAF50", "#212121")

    private lateinit var bar: TextView
    private lateinit var body: LinearLayout
    private lateinit var prefs: SharedPreferences

    private var screen = "home"
    private var kind = "html"
    private var fileUri: Uri? = null
    private var fileName = ""
    private var iconBmp: Bitmap? = null
    private var appName = ""
    private var colorHex = "#0F9688"
    private var nameEt: EditText? = null
    private var lastApk: File? = null
    private var saveSource: File? = null
    private val perm = linkedMapOf(
        "camera" to false, "mic" to false, "gallery" to true, "location" to false,
        "fullscreen" to false, "internet" to true, "landscape" to false
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("h2a", MODE_PRIVATE)
        window.statusBarColor = teal
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#F5F7FA")) }
        bar = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 24f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL; compoundDrawablePadding = dp(12)
            setBackgroundColor(teal); setPadding(dp(18), dp(14), dp(18), dp(14))
            val logo = BitmapFactory.decodeResource(resources, R.drawable.logo)
            val d = android.graphics.drawable.BitmapDrawable(resources, logo)
            d.setBounds(0, 0, dp(40), dp(40))
            setCompoundDrawables(d, null, null, null)
        }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(32)) }
        val sv = ScrollView(this).apply { addView(body) }
        root.addView(bar)
        root.addView(sv, LinearLayout.LayoutParams(-1, -1))
        setContentView(root)
        home()
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun reset(t: String) { bar.text = t; body.removeAllViews() }
    private fun tv(t: String, size: Float = 16f, color: Int = dark, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun bg(fill: Int, radius: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(radius).toFloat(); if (stroke != 0) setStroke(dp(2), stroke)
    }
    private fun gap(h: Int = 12) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun btn(t: String, color: Int = teal, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE); textSize = 17f
        background = bg(color, 14); setPadding(dp(16), dp(14), dp(16), dp(14)); setOnClickListener { onClick() }
    }
    private fun bigCard(badge: String, badgeColor: Int, title: String, sub: String, onClick: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = bg(Color.parseColor("#F0F5F4"), 24, Color.parseColor("#3A3F55"))
            setPadding(dp(18), dp(18), dp(18), dp(18)); setOnClickListener { onClick() }
        }
        row.addView(tv(badge, 20f, Color.WHITE, true).apply { gravity = Gravity.CENTER; background = bg(badgeColor, 18) },
            LinearLayout.LayoutParams(dp(64), dp(64)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, dp(8), 0) }
        col.addView(tv(title, 20f, dark, true)); col.addView(tv(sub, 14f, grey))
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(tv("›", 30f, teal, true))
        return row
    }
    private fun nameOf(u: Uri): String {
        contentResolver.query(u, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i)
        }
        return u.lastPathSegment ?: "file"
    }
    private fun decode(u: Uri): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth / s > 1024) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
    } catch (e: Exception) { null }

    private fun makeIcon(): ByteArray {
        val s = 192
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor(colorHex) }
        val rect = RectF(0f, 0f, s.toFloat(), s.toFloat())
        c.save()
        c.clipPath(Path().apply { addRoundRect(rect, 40f, 40f, Path.Direction.CW) })
        c.drawRect(rect, p)
        val ic = iconBmp
        if (ic != null) {
            val side = minOf(ic.width, ic.height)
            val src = Rect((ic.width - side) / 2, (ic.height - side) / 2, (ic.width + side) / 2, (ic.height + side) / 2)
            c.drawBitmap(ic, src, rect, Paint(Paint.FILTER_BITMAP_FLAG))
        } else {
            p.color = Color.WHITE; p.textSize = 110f; p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD
            c.drawText((appName.trim().take(1).ifBlank { "A" }).uppercase(), s / 2f, s / 2f + 38f, p)
        }
        c.restore()
        val bo = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, bo)
        return bo.toByteArray()
    }

    // ---------- 1. Home ----------
    private fun home() {
        screen = "home"; reset("HTML to APK")
        body.addView(bigCard("</>", teal, "HTML File to APK", "Convert HTML file to Android APK") { pick("html") })
        body.addView(gap())
        body.addView(bigCard("ZIP", Color.parseColor("#2E9E4F"), "ZIP File to APK", "Convert ZIP (website) to Android APK") { pick("zip") })
        body.addView(gap(24)); body.addView(tv("MORE", 14f, grey, true)); body.addView(gap(8))
        body.addView(btn("My Apps (${apps().length()})") { myApps() })
        body.addView(gap(8))
        body.addView(btn("How to Use", grey) { howTo() })
    }

    private fun pick(k: String) {
        kind = k
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 1)
    }

    // ---------- 2. Look ----------
    private fun look() {
        screen = "look"; reset("Step 2/5 · App Look")
        body.addView(tv("File: $fileName", 14f, grey)); body.addView(gap())
        body.addView(tv("App name", 16f, dark, true)); body.addView(gap(6))
        val et = EditText(this).apply {
            setText(appName); hint = "My App"; filters = arrayOf(InputFilter.LengthFilter(30))
            setTextColor(dark); background = bg(Color.WHITE, 12, grey); setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        nameEt = et
        body.addView(et); body.addView(gap(18))
        body.addView(tv("Icon color / theme color", 16f, dark, true)); body.addView(gap(8))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        colors.forEach { c ->
            val v = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL; setColor(Color.parseColor(c))
                    if (c == colorHex) setStroke(dp(4), dark)
                }
                setOnClickListener { appName = et.text.toString(); colorHex = c; look() }
            }
            row.addView(v, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(8) })
        }
        body.addView(HorizontalScrollView(this).apply { addView(row) })
        body.addView(gap(18))
        body.addView(tv("Icon", 16f, dark, true)); body.addView(gap(6))
        appName = et.text.toString()
        val iconBytes = makeIcon()
        val prev = BitmapFactory.decodeByteArray(iconBytes, 0, iconBytes.size)
        body.addView(ImageView(this).apply { setImageBitmap(prev) }, LinearLayout.LayoutParams(dp(96), dp(96)))
        body.addView(gap(8))
        body.addView(btn("Choose icon image (optional)", grey) {
            appName = et.text.toString()
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), 2)
        })
        if (iconBmp != null) { body.addView(gap(8)); body.addView(btn("Remove icon image", grey) { appName = et.text.toString(); iconBmp = null; look() }) }
        body.addView(gap(20))
        body.addView(btn("Next  →") { appName = et.text.toString().trim().ifBlank { "My App" }; perms() })
    }

    // ---------- 3. Permissions ----------
    private fun perms() {
        screen = "perms"; reset("Step 3/5 · Permissions")
        body.addView(tv("Generated app ko kya allow karna hai?", 15f, grey)); body.addView(gap(10))
        listOf(
            "camera" to "Camera access", "mic" to "Microphone access", "gallery" to "Gallery / file upload",
            "location" to "Location (GPS)", "fullscreen" to "Fullscreen (status bar hide)",
            "internet" to "Internet access", "landscape" to "Landscape orientation"
        ).forEach { (k, label) ->
            body.addView(Switch(this).apply {
                text = label; textSize = 17f; setTextColor(dark); isChecked = perm[k] == true
                setPadding(dp(16), dp(14), dp(16), dp(14)); background = bg(Color.WHITE, 14)
                setOnCheckedChangeListener { _, c -> perm[k] = c }
            })
            body.addView(gap(8))
        }
        body.addView(gap(10))
        body.addView(btn("Next  →") { generate() })
    }

    // ---------- 4. Generate ----------
    private fun generate() {
        screen = "gen"; reset("Step 4/5 · Generate")
        body.addView(tv(appName, 22f, dark, true))
        body.addView(tv("File: $fileName", 14f, grey)); body.addView(gap(6))
        val on = perm.filter { it.value }.keys.joinToString(", ").ifBlank { "none" }
        body.addView(tv("Allowed: $on", 14f, grey)); body.addView(gap(20))
        val status = tv("", 15f, grey).apply { setTextIsSelectable(true) }
        val pb = ProgressBar(this).apply { visibility = View.GONE }
        val b = btn("Generate APK") {}
        b.setOnClickListener {
            b.isEnabled = false; pb.visibility = View.VISIBLE; status.setTextColor(grey)
            Thread {
                try {
                    val cfg = JSONObject().apply { put("name", appName); put("color", colorHex); perm.forEach { (k, v) -> put(k, v) } }
                    val dir = File(filesDir, "apks").apply { mkdirs() }
                    val safe = appName.replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "app" }
                    val out = File(dir, "${safe}_${System.currentTimeMillis()}.apk")
                    ApkBuilder.build(this, kind, fileUri!!, cfg, makeIcon(), out) { m -> runOnUiThread { status.text = m } }
                    addApp(appName, out)
                    lastApk = out
                    runOnUiThread { done() }
                } catch (e: Throwable) {
                    runOnUiThread {
                        pb.visibility = View.GONE; b.isEnabled = true
                        status.setTextColor(Color.RED); status.text = "Error: ${e.javaClass.simpleName}: ${e.message}"
                    }
                }
            }.start()
        }
        body.addView(b); body.addView(gap(12)); body.addView(pb); body.addView(status)
    }

    // ---------- 5. Done ----------
    private fun done() {
        screen = "done"; reset("Step 5/5 · Download")
        val f = lastApk!!
        body.addView(tv("✅ App tayar hai!", 24f, teal, true)); body.addView(gap(6))
        body.addView(tv("$appName  ·  ${f.length() / 1024} KB", 15f, grey)); body.addView(gap(20))
        body.addView(btn("Install now") { install(f) }); body.addView(gap(10))
        body.addView(btn("Download (phone mein save)", Color.parseColor("#2E9E4F")) { saveCopy(f) }); body.addView(gap(10))
        body.addView(btn("My Apps", grey) { myApps() }); body.addView(gap(10))
        body.addView(btn("Naya app banayein", grey) { home() })
    }

    private fun install(f: File) {
        if (!f.exists()) { toast("File nahi mili"); return }
        if (!packageManager.canRequestPackageInstalls()) {
            toast("Is app ke liye 'Allow from this source' on karein, phir wapas aa kar Install dabayein")
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        val u = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    }

    private fun saveCopy(f: File) {
        saveSource = f
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType("application/vnd.android.package-archive").putExtra(Intent.EXTRA_TITLE, f.name), 3)
    }

    // ---------- My Apps ----------
    private fun apps(): JSONArray = try { JSONArray(prefs.getString("apps", "[]")) } catch (e: Exception) { JSONArray() }
    private fun addApp(name: String, f: File) {
        val old = apps(); val n = JSONArray()
        n.put(JSONObject().put("name", name).put("path", f.absolutePath).put("time", System.currentTimeMillis()))
        for (i in 0 until old.length()) n.put(old.get(i))
        prefs.edit().putString("apps", n.toString()).apply()
    }
    private fun removeApp(i: Int) {
        val old = apps(); val n = JSONArray()
        for (k in 0 until old.length()) {
            if (k == i) File(old.getJSONObject(k).getString("path")).delete() else n.put(old.get(k))
        }
        prefs.edit().putString("apps", n.toString()).apply()
    }
    private fun myApps() {
        screen = "apps"; reset("My Apps")
        val list = apps()
        if (list.length() == 0) body.addView(tv("Abhi koi app nahi bani.", 16f, grey))
        for (i in 0 until list.length()) {
            val o = list.getJSONObject(i); val f = File(o.getString("path"))
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(Color.WHITE, 16); setPadding(dp(16), dp(14), dp(16), dp(14)) }
            card.addView(tv(o.getString("name"), 18f, dark, true))
            card.addView(tv(SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(o.getLong("time"))) + "  ·  " + (f.length() / 1024) + " KB", 13f, grey))
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, 0) }
            fun small(t: String, c: Int, a: () -> Unit) = btn(t, c, a).apply { textSize = 14f }
            r.addView(small("Install", teal) { install(f) }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
            r.addView(small("Save", Color.parseColor("#2E9E4F")) { saveCopy(f) }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
            r.addView(small("Delete", Color.parseColor("#D32F2F")) { removeApp(i); myApps() }, LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(r)
            body.addView(card); body.addView(gap(10))
        }
    }

    private fun howTo() {
        AlertDialog.Builder(this).setTitle("How to Use").setMessage(
            "1. HTML ya ZIP card dabayein aur file chunein.\n" +
            "2. App ka naam, color aur icon chunein.\n" +
            "3. Camera, mic, gallery waghera ke toggles chunein.\n" +
            "4. Generate APK dabayein.\n" +
            "5. Install ya Download dabayein.\n\n" +
            "ZIP ke andar index.html zaroor honi chahiye.\n" +
            "Install ke waqt 'Allow from this source' on karna parta hai."
        ).setPositiveButton("OK", null).show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (res != RESULT_OK) return
        val uri = data?.data ?: return
        when (rc) {
            1 -> {
                val n = nameOf(uri); val l = n.lowercase()
                val ok = if (kind == "html") l.endsWith(".html") || l.endsWith(".htm") else l.endsWith(".zip")
                if (!ok) { toast(if (kind == "html") "Sirf .html file chunein" else "Sirf .zip file chunein"); return }
                fileUri = uri; fileName = n; appName = n.substringBeforeLast('.').take(30); iconBmp = null
                look()
            }
            2 -> { iconBmp = decode(uri); look() }
            3 -> try {
                contentResolver.openOutputStream(uri)?.use { o -> saveSource?.inputStream()?.use { it.copyTo(o) } }
                toast("APK save ho gayi")
            } catch (e: Exception) { toast("Save nahi hui: ${e.message}") }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (screen) {
            "home" -> super.onBackPressed()
            "perms" -> look()
            "gen" -> perms()
            "look", "done", "apps" -> home()
            else -> home()
        }
    }
}
